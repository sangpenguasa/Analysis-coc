import "dotenv/config";
import path from "node:path";
import { createApp } from "./server/_core/app";

const app = createApp();
const indexHtml = path.resolve(process.cwd(), "dist/public/index.html");

app.get("/404", (_req, res) => res.status(404).sendFile(indexHtml));
app.get("*", (_req, res) => res.sendFile(indexHtml));

export default app;
