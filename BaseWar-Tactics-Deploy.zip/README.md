# BaseWar Tactics

Website analisis base war Clash of Clans. Seret screenshot base, tandai troop/hero/spell yang tersedia, lalu dapatkan komposisi dan langkah deployment yang divisualisasikan langsung di atas gambar.

## Deploy lewat GitHub ke Vercel

Arsip ZIP berisi source project (tanpa folder dependency, riwayat Git, build lokal, atau secret). Setelah diekstrak, buat repository kosong di GitHub lalu push file project:

```bash
git init
git add .
git commit -m "Deploy BaseWar Tactics"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

Di Vercel, pilih **Add New → Project**, import repository tadi, lalu deploy dengan preset Express dan konfigurasi yang disediakan di `vercel.json`. Build akan menghasilkan aset Vite dan menyalinnya ke `public/`; Express menyediakan endpoint API dan fallback SPA.

GitHub berfungsi sebagai hosting source code. GitHub Pages saja tidak menjalankan endpoint Node/Express yang dibutuhkan fitur analisis.

## Aktifkan analisis AI

Tambahkan variabel server-side ini di **Vercel → Project Settings → Environment Variables**, lalu redeploy:

- `OPENAI_API_KEY`: API key milik Anda. Jangan menaruhnya di source code, ZIP, atau variabel berawalan `VITE_`.
- `BASEWAR_LLM_PROVIDER`: `openai`.
- `OPENAI_MODEL`: default `gpt-6.1-sol`; dapat diganti dengan model lain yang tersedia untuk akun API dan mendukung input gambar serta Structured Outputs.
- `OPENAI_API_BASE`: opsional; default `https://api.openai.com/v1`.

Biaya pemrosesan AI ditagihkan oleh provider pada API key yang Anda konfigurasi. ZIP tidak menyertakan key. Tanpa `OPENAI_API_KEY`, halaman tetap dapat dibuka tetapi analisis tidak dapat dijalankan. Contoh nama variabel juga tersedia di `.env.example`.

## Jalankan lokal

```bash
corepack enable
corepack prepare pnpm@10.18.0 --activate
pnpm install --frozen-lockfile
cp .env.example .env
# Isi OPENAI_API_KEY di .env untuk memakai API OpenAI secara lokal.
pnpm dev
```

Perintah tambahan: `pnpm check`, `pnpm test`, `pnpm build`, dan `pnpm build:vercel`.

## Data dan ukuran screenshot

Seret screenshot profil akun seperti tab “Profilku” ke uploader profil. AI mencoba membaca unit aktif dan level yang tampak; pengguna dapat mengoreksi nama, level, availability, serta Town Hall yang tidak terbaca sebelum menjalankan strategi. Screenshot profil dipakai untuk ekstraksi dan tidak disimpan di server; loadout hasilnya disimpan di browser.

Saat analisis base atau pembacaan profil dijalankan, gambar dan data yang diperlukan dikirim melalui backend ke provider AI yang dikonfigurasi. Biaya mengikuti provider tersebut. Screenshot dibatasi hingga 2,5 MB setelah kompresi agar request tetap di bawah batas payload Vercel Functions; file asli maksimal 16 MB. Selalu periksa hasil vision karena ikon/level kecil atau abu-abu dapat salah dibaca.

Endpoint AI membatasi hingga 4 permintaan per menit per alamat IP pada satu proses server. Pada deployment serverless, batas ini bersifat best-effort per instance, bukan kuota global; atur spending limit/rate limit pada provider API sebelum membuka situs ke publik.

## Referensi deployment

- [Express on Vercel](https://vercel.com/docs/frameworks/backend/express) — Express app diekspor sebagai Function; aset statis diambil dari `public/`.
- [Vite on Vercel](https://vercel.com/docs/frameworks/frontend/vite) — build Vite dan penanganan SPA.
- [Vercel Functions limits](https://vercel.com/docs/functions/limitations) — batas body request/function.
- [OpenAI models](https://developers.openai.com/api/docs/models) — model dan dukungan input gambar.
- [OpenAI Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs) — format JSON berskema.
