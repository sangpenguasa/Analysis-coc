import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { analyzeAttack, attackInputSchema } from "./_core/strategyAnalysis";
import { parsePlayerProfile, profileParseInputSchema } from "./_core/profileAnalysis";
import { enforceAiRateLimit } from "./_core/rateLimit";

const aiProcedure = publicProcedure.use(({ ctx, next }) => {
  enforceAiRateLimit(ctx.req, ctx.res);
  return next();
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  strategy: router({
    parseProfile: aiProcedure
      .input(profileParseInputSchema)
      .mutation(({ input }) => parsePlayerProfile(input)),
    analyze: aiProcedure
      .input(attackInputSchema)
      .mutation(({ input }) => analyzeAttack(input)),
  }),
});

export type AppRouter = typeof appRouter;
