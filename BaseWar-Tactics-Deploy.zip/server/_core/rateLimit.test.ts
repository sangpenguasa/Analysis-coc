import { describe, expect, it } from "vitest";
import { TRPCError } from "@trpc/server";
import { enforceAiRateLimit } from "./rateLimit";

describe("AI request rate limit", () => {
  it("blocks the fifth request in a minute and reports retry delay", () => {
    const ip = `198.51.100.${Math.random().toString(16).slice(2)}`;
    const request = {
      ip,
      get: (name: string) => name.toLowerCase() === "x-forwarded-for" ? ip : undefined,
    };
    const headers = new Map<string, string>();
    const response = { setHeader: (name: string, value: string) => headers.set(name, value) };

    for (let index = 0; index < 4; index += 1) {
      enforceAiRateLimit(request, response, 1_000 + index);
    }

    expect(() => enforceAiRateLimit(request, response, 1_004)).toThrow(TRPCError);
    expect(headers.get("Retry-After")).toBe("60");
    expect(() => enforceAiRateLimit(request, response, 61_001)).not.toThrow();
  });
});
