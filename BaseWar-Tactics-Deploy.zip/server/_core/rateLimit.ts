import { TRPCError } from "@trpc/server";

type RequestLike = {
  get: (name: string) => string | undefined;
  ip?: string;
};

type ResponseLike = {
  setHeader: (name: string, value: string) => unknown;
};

const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 4;
const MAX_TRACKED_ADDRESSES = 5_000;
const requestTimes = new Map<string, number[]>();

/** Best-effort in-memory throttle; use provider-side budgets or shared edge limits for a global quota. */
export function enforceAiRateLimit(request: RequestLike, response: ResponseLike, now = Date.now()) {
  const forwardedAddress = request.get("x-forwarded-for")?.split(",")[0]?.trim();
  const address = forwardedAddress || request.ip || "unknown";
  const recent = (requestTimes.get(address) ?? []).filter(timestamp => now - timestamp < WINDOW_MS);

  requestTimes.delete(address);
  requestTimes.set(address, recent);

  if (recent.length >= MAX_REQUESTS_PER_WINDOW) {
    const retryAfter = Math.max(1, Math.ceil((recent[0]! + WINDOW_MS - now) / 1000));
    response.setHeader("Retry-After", String(retryAfter));
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: `Batas sementara permintaan AI tercapai. Coba lagi dalam ${retryAfter} detik.`,
    });
  }

  recent.push(now);

  while (requestTimes.size > MAX_TRACKED_ADDRESSES) {
    const oldestAddress = requestTimes.keys().next().value as string | undefined;
    if (!oldestAddress) break;
    requestTimes.delete(oldestAddress);
  }
}
