// Platform values are read at use time. Private keys stay server-side.
export const ENV = {
  get appId() { return process.env.MANUS_PROJECT_ID ?? ""; },
  get cookieSecret() { return process.env.MANUS_JWT_SECRET ?? ""; },
  get databaseUrl() { return process.env.DATABASE_URL ?? ""; },
  get oAuthServerUrl() { return process.env.MANUS_OAUTH_API_URL ?? ""; },
  // Preserve the legacy hint when supplied; otherwise roles remain application data.
  get ownerOpenId() { return process.env.OWNER_OPEN_ID ?? ""; },
  get isProduction() { return process.env.NODE_ENV === "production"; },
  get forgeApiUrl() { return process.env.MANUS_API_URL ?? ""; },
  get forgeApiKey() { return process.env.MANUS_API_KEY ?? ""; },
  get llmProvider() { return process.env.BASEWAR_LLM_PROVIDER ?? ""; },
  get openAiApiUrl() { return process.env.OPENAI_API_BASE ?? "https://api.openai.com/v1"; },
  get openAiApiKey() { return process.env.OPENAI_API_KEY ?? ""; },
  get openAiModel() { return process.env.OPENAI_MODEL ?? "gpt-6.1-sol"; },
};
