import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Crosshair,
  Crown,
  FileImage,
  Flame,
  Layers3,
  LoaderCircle,
  LockKeyhole,
  MapPin,
  Plus,
  RotateCcw,
  Shield,
  Sparkles,
  Swords,
  Target,
  Trash2,
  Upload,
  WandSparkles,
  X,
} from "lucide-react";
import { toast } from "sonner";
import type {
  AttackPhase,
  AttackPlan,
  ProfileParseResult,
  PlayerProfile,
  UnitCategory,
} from "@shared/strategy";
import { trpc } from "@/lib/trpc";

const PROFILE_STORAGE_KEY = "basewar-profile-v1";
const CATALOG: Record<UnitCategory, string[]> = {
  troops: [
    "Barbarian", "Archer", "Giant", "Goblin", "Wall Breaker", "Balloon", "Wizard", "Healer",
    "Dragon", "P.E.K.K.A.", "Baby Dragon", "Miner", "Electro Dragon", "Yeti", "Valkyrie",
    "Golem", "Lava Hound", "Bowler", "Ice Golem", "Dragon Rider", "Root Rider", "Hog Rider",
  ],
  heroes: ["Barbarian King", "Archer Queen", "Minion Prince", "Grand Warden", "Royal Champion"],
  spells: [
    "Lightning Spell", "Healing Spell", "Rage Spell", "Jump Spell", "Freeze Spell", "Clone Spell",
    "Invisibility Spell", "Poison Spell", "Earthquake Spell", "Haste Spell", "Skeleton Spell",
    "Bat Spell", "Recall Spell", "Overgrowth Spell", "Revive Spell",
  ],
};

const CATEGORY_LABELS: Record<UnitCategory, string> = {
  troops: "Troop",
  heroes: "Hero",
  spells: "Spell",
};

const CATEGORY_COUNTS: Record<UnitCategory, string> = {
  troops: "troop terbuka",
  heroes: "hero tersedia",
  spells: "spell tersedia",
};

const emptyProfile: PlayerProfile = {
  townHall: null,
  armyCapacity: undefined,
  troops: [],
  heroes: [],
  spells: [],
};

function readProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(PROFILE_STORAGE_KEY);
    if (!raw) return emptyProfile;
    const saved = JSON.parse(raw) as PlayerProfile;
    if (!Array.isArray(saved.troops) || !Array.isArray(saved.heroes) || !Array.isArray(saved.spells)) return emptyProfile;
    return {
      townHall: Number.isInteger(saved.townHall) ? saved.townHall : null,
      armyCapacity: Number.isInteger(saved.armyCapacity) && saved.armyCapacity! > 0 ? saved.armyCapacity : undefined,
      troops: saved.troops,
      heroes: saved.heroes,
      spells: saved.spells,
    };
  } catch {
    return emptyProfile;
  }
}

function confidenceLabel(confidence: AttackPlan["confidence"]) {
  return confidence === "tinggi" ? "Terbaca jelas" : confidence === "sedang" ? "Perlu cek detail" : "Visibilitas rendah";
}

function kindLabel(kind: AttackPhase["kind"]) {
  if (kind === "troop") return "TROOP";
  if (kind === "hero") return "HERO";
  if (kind === "spell") return "SPELL";
  return "ARAH";
}

function toDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Gambar tidak bisa dibaca."));
    reader.onerror = () => reject(new Error("Gambar tidak bisa dibaca."));
    reader.readAsDataURL(file);
  });
}

async function prepareImage(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const maxSide = 1800;
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Pratinjau gambar tidak dapat disiapkan.");
  context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  const compressed = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("Gambar gagal dikompres.")), "image/jpeg", 0.88);
  });
  if (compressed.size > 2.5 * 1024 * 1024) throw new Error("Ukuran gambar setelah kompresi masih lebih dari 2,5 MB. Gunakan screenshot yang lebih kecil.");
  return toDataUrl(compressed);
}

export default function Home() {
  const [profile, setProfile] = useState<PlayerProfile>(() => readProfile());
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const [imageName, setImageName] = useState("");
  const [imageDimensions, setImageDimensions] = useState({ width: 16, height: 9 });
  const [dragging, setDragging] = useState(false);
  const [activeCategory, setActiveCategory] = useState<UnitCategory>("troops");
  const [unitSearch, setUnitSearch] = useState("");
  const [activePhase, setActivePhase] = useState<number | null>(null);
  const [plan, setPlan] = useState<AttackPlan | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileScreenshot, setProfileScreenshot] = useState<string | null>(null);
  const [profileScreenshotName, setProfileScreenshotName] = useState("");
  const [profileDragging, setProfileDragging] = useState(false);
  const [profileParseResult, setProfileParseResult] = useState<ProfileParseResult | null>(null);
  const [profilePreparing, setProfilePreparing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const profileFileInputRef = useRef<HTMLInputElement>(null);
  const profilePreparingRef = useRef(false);
  const profileParseRequestRef = useRef(0);
  const analysis = trpc.strategy.analyze.useMutation();
  const profileParser = trpc.strategy.parseProfile.useMutation();

  useEffect(() => {
    try {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
    } catch {
      // Browser storage can be unavailable in private or restricted contexts.
    }
  }, [profile]);

  const filteredUnits = useMemo(() => {
    const query = unitSearch.trim().toLowerCase();
    const names = Array.from(new Set([...CATALOG[activeCategory], ...profile[activeCategory].map(unit => unit.name)]));
    return names.filter(name => name.toLowerCase().includes(query));
  }, [activeCategory, profile, unitSearch]);

  const selectedCount = profile[activeCategory].length;
  const hasProfile = Boolean(profile.townHall && profile.troops.length > 0);
  const visiblePhases = plan
    ? activePhase === null ? plan.phases : plan.phases.filter(phase => phase.id === activePhase)
    : [];

  const pickImage = async (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/") || !["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      toast.error("Gunakan gambar JPEG, PNG, atau WebP.");
      return;
    }
    if (file.size > 16 * 1024 * 1024) {
      toast.error("Ukuran gambar maksimal 16 MB sebelum kompresi.");
      return;
    }
    try {
      const nextImage = await prepareImage(file);
      setImageDataUrl(nextImage);
      setImageName(file.name);
      setPlan(null);
      setActivePhase(null);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Gambar gagal diproses.");
    }
  };

  const onFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    void pickImage(event.target.files?.[0]);
    event.target.value = "";
  };

  const pickProfileScreenshot = async (file?: File) => {
    if (!file || profileParser.isPending || profilePreparingRef.current) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      toast.error("Gunakan screenshot profil JPEG, PNG, atau WebP.");
      return;
    }
    if (file.size > 16 * 1024 * 1024) {
      toast.error("Ukuran screenshot profil maksimal 16 MB sebelum kompresi.");
      return;
    }
    profilePreparingRef.current = true;
    setProfilePreparing(true);
    const requestId = ++profileParseRequestRef.current;
    try {
      const screenshot = await prepareImage(file);
      if (requestId !== profileParseRequestRef.current) return;
      setProfileScreenshot(screenshot);
      setProfileScreenshotName(file.name);
      setProfileParseResult(null);
      const parsed = await profileParser.mutateAsync({ imageDataUrl: screenshot });
      if (requestId !== profileParseRequestRef.current) return;
      setProfileParseResult(parsed);
      const detectedUnits = parsed.troops.length + parsed.heroes.length + parsed.spells.length;
      if (parsed.troops.length === 0) {
        toast.error("Troop belum terbaca dengan yakin. Profil lama tetap dipakai; coba screenshot yang lebih jelas.");
        return;
      }
      setProfile(current => ({
        ...current,
        townHall: parsed.townHall ?? current.townHall,
        troops: parsed.troops,
        heroes: parsed.heroes,
        spells: parsed.spells,
      }));
      setActiveCategory("troops");
      setUnitSearch("");
      toast.success(`${detectedUnits} unit terbaca. Periksa hasilnya sebelum analisis base.`);
    } catch (error) {
      if (requestId === profileParseRequestRef.current) {
        toast.error(error instanceof Error ? error.message : "Screenshot profil gagal dibaca.");
      }
    } finally {
      if (requestId === profileParseRequestRef.current) {
        profilePreparingRef.current = false;
        setProfilePreparing(false);
      }
    }
  };

  const onProfileFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    void pickProfileScreenshot(event.target.files?.[0]);
    event.target.value = "";
  };

  const toggleUnit = (category: UnitCategory, name: string, selected: boolean) => {
    setProfile(current => {
      const existing = current[category];
      const next = selected
        ? [...existing, { name, level: 1, ...(category === "spells" ? { quantity: 1 } : {}) }]
        : existing.filter(unit => unit.name !== name);
      return { ...current, [category]: next };
    });
  };

  const updateUnit = (category: UnitCategory, name: string, field: "level" | "quantity", value: number | null) => {
    setProfile(current => ({
      ...current,
      [category]: current[category].map(unit => {
        if (unit.name !== name) return unit;
        return field === "level" ? { ...unit, level: value } : { ...unit, quantity: value ?? 1 };
      }),
    }));
  };

  const addCustomUnit = () => {
    const customName = unitSearch.trim();
    if (!customName) return;
    if (CATALOG[activeCategory].some(name => name.toLowerCase() === customName.toLowerCase())) {
      toast.message("Unit itu sudah ada di daftar.");
      return;
    }
    if (profile[activeCategory].some(unit => unit.name.toLowerCase() === customName.toLowerCase())) {
      toast.message("Unit itu sudah dipilih.");
      return;
    }
    toggleUnit(activeCategory, customName, true);
    setUnitSearch("");
  };

  const handleAnalyze = async () => {
    if (!imageDataUrl) {
      toast.error("Unggah screenshot base musuh terlebih dahulu.");
      return;
    }
    if (!profile.townHall) {
      toast.error("Pilih level Town Hall akun Anda terlebih dahulu.");
      return;
    }
    if (profile.troops.length === 0) {
      toast.error("Tandai setidaknya satu troop yang tersedia di akun Anda.");
      return;
    }
    const profileForAnalysis = { ...profile, townHall: Number(profile.townHall) };
    try {
      const result = await analysis.mutateAsync({ imageDataUrl, profile: profileForAnalysis });
      setPlan(result);
      setActivePhase(null);
      window.setTimeout(() => document.getElementById("workbench")?.scrollIntoView({ behavior: "smooth", block: "start" }), 120);
      toast.success("Rencana serangan sudah siap.");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Analisis gagal diproses. Coba lagi.";
      toast.error(message);
    }
  };

  const removeImage = () => {
    setImageDataUrl(null);
    setImageName("");
    setPlan(null);
    setActivePhase(null);
  };

  const jumpTo = (id: string) => {
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="brand-lockup">
          <span className="brand-icon"><Crosshair size={20} strokeWidth={2.3} /></span>
          <span className="brand-name">base<span>war</span><small>TACTICS LAB</small></span>
        </div>
        <div className="sidebar-caption">WORKSPACE</div>
        <nav className="side-nav" aria-label="Navigasi utama">
          <button className="nav-link active" onClick={() => jumpTo("workbench")}><Crosshair size={17} />Analisis base <span className="nav-pip" /></button>
          <button className="nav-link" onClick={() => jumpTo("troop-profile")}><Layers3 size={17} />Profil pasukan</button>
          <button className="nav-link" onClick={() => jumpTo("analysis-result")}><MapPin size={17} />Rencana serang</button>
        </nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-note">
          <div className="sidebar-note-icon"><Shield size={16} /></div>
          <div><strong>Profil aman</strong><span>Tanpa kata sandi akun</span></div>
          <LockKeyhole size={14} className="sidebar-lock" />
        </div>
        <div className="sidebar-foot">BUILD YOUR NEXT 3-STAR</div>
      </aside>

      {menuOpen && <button className="mobile-backdrop" aria-label="Tutup menu" onClick={() => setMenuOpen(false)} />}

      <main className="main-column">
        <header className="topbar">
          <button className="menu-toggle" aria-label="Buka navigasi" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X size={19} /> : <Layers3 size={19} />}</button>
          <div className="breadcrumb"><span>CLAN WAR</span><ChevronRight size={14} /><strong>Attack planner</strong></div>
          <div className="topbar-right"><span className="online-dot" />AI ANALYZER <span className="beta-pill">BETA</span></div>
        </header>

        <div className="page-content">
          <section className="page-heading" id="workbench">
            <div>
              <div className="eyebrow"><span className="eyebrow-line" />WAR ROOM <span className="eyebrow-slash">/</span> BASE INTELLIGENCE</div>
              <h1>Serang dengan <em>rencana.</em></h1>
              <p>Unggah base lawan. Susun pasukanmu. Dapatkan panduan serangan langsung di peta.</p>
            </div>
            <div className="heading-mark"><span>COC</span><Swords size={18} /><i>01</i></div>
          </section>

          <div className="workspace-layout">
            <section className="base-column">
              <div className="section-topline">
                <div className="section-label"><span className="step-index">01</span><div><span>INTEL BASE</span><strong>Foto base musuh</strong></div></div>
                {imageDataUrl ? <span className="image-ready"><i />BASE TERUNGGAH</span> : <span className="quiet-status">MENUNGGU GAMBAR</span>}
              </div>

              <div
                className={`upload-frame ${dragging ? "dragging" : ""} ${imageDataUrl ? "has-image" : ""}`}
                onDragOver={event => { event.preventDefault(); setDragging(true); }}
                onDragLeave={event => { if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setDragging(false); }}
                onDrop={event => { event.preventDefault(); setDragging(false); void pickImage(event.dataTransfer.files?.[0]); }}
              >
                <input ref={fileInputRef} className="visually-hidden" type="file" accept="image/png,image/jpeg,image/webp" onChange={onFileChange} />
                {imageDataUrl ? (
                  <div className="base-map-wrap" style={{ aspectRatio: `${imageDimensions.width} / ${imageDimensions.height}` }}>
                    <img
                      className="base-map-image"
                      src={imageDataUrl}
                      alt="Pratinjau screenshot base Clash of Clans yang akan dianalisis"
                      onLoad={event => setImageDimensions({ width: event.currentTarget.naturalWidth, height: event.currentTarget.naturalHeight })}
                    />
                    {plan && (
                      <>
                        <svg className="map-arrows" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
                          <defs>
                            <marker id="arrow-tip" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" /></marker>
                          </defs>
                          {visiblePhases.filter(phase => Math.abs(phase.targetX - phase.x) + Math.abs(phase.targetY - phase.y) > 3).map(phase => (
                            <line key={`arrow-${phase.id}`} x1={phase.x} y1={phase.y} x2={phase.targetX} y2={phase.targetY} className={`map-arrow arrow-${phase.kind}`} markerEnd="url(#arrow-tip)" />
                          ))}
                        </svg>
                        {plan.keyTargets.map((target, index) => (
                          <div key={`target-${index}`} className={`target-pin target-${target.severity}`} style={{ left: `${target.x}%`, top: `${target.y}%` }} title={`${target.name}: ${target.note}`}>
                            <span>{index + 1}</span>
                          </div>
                        ))}
                        {visiblePhases.map(phase => (
                          <button key={`phase-${phase.id}`} className={`phase-pin pin-${phase.kind} ${activePhase === phase.id ? "pin-selected" : ""}`} style={{ left: `${phase.x}%`, top: `${phase.y}%` }} onClick={() => setActivePhase(phase.id)} title={`${phase.title}: ${phase.quantity} ${phase.unit}`}>
                            <span>{phase.id}</span>
                          </button>
                        ))}
                      </>
                    )}
                    <div className="map-coord-label"><Crosshair size={12} /> MAP OVERLAY {plan ? "ACTIVE" : "READY"}</div>
                    <div className="map-corner-tag">{imageDimensions.width} × {imageDimensions.height}</div>
                  </div>
                ) : (
                  <button className="upload-prompt" onClick={() => fileInputRef.current?.click()}>
                    <div className="upload-crosshair"><Crosshair size={27} strokeWidth={1.55} /><span><Plus size={12} /></span></div>
                    <strong>{dragging ? "Lepaskan untuk unggah" : "Letakkan screenshot base di sini"}</strong>
                    <span className="upload-support">Seret dan lepas gambar langsung ke area ini</span>
                    <span className="upload-or"><i />ATAU PILIH MANUAL<i /></span>
                    <span className="upload-picker"><Upload size={14} /> PILIH GAMBAR <ArrowRight size={13} /></span>
                    <span className="upload-types">JPG, PNG, WebP <b>·</b> Maks. 16 MB</span>
                  </button>
                )}
              </div>

              {imageDataUrl && (
                <div className="image-toolbar">
                  <div className="file-meta"><FileImage size={15} /><span>{imageName || "base-screenshot.jpg"}</span><span className="file-meta-check"><Check size={12} /></span></div>
                  <div className="toolbar-actions">
                    <button className="tool-button" onClick={() => fileInputRef.current?.click()}><RotateCcw size={13} /> Ganti foto</button>
                    <button className="tool-button danger-tool" onClick={removeImage}><Trash2 size={13} /> Hapus</button>
                  </div>
                </div>
              )}

              {plan ? (
                <div className="phase-controls">
                  <div className="phase-control-top"><span><span className="legend-light" />TAHAP SERANGAN</span><button onClick={() => setActivePhase(null)} className={activePhase === null ? "selected" : ""}><Layers3 size={13} /> Semua</button></div>
                  <div className="phase-chip-list">
                    {plan.phases.map(phase => (
                      <button key={phase.id} className={`phase-chip ${activePhase === phase.id ? "selected" : ""}`} onClick={() => setActivePhase(phase.id)}>
                        <span className={`phase-chip-num chip-${phase.kind}`}>{String(phase.id).padStart(2, "0")}</span><span>{phase.title}</span><ChevronDown size={13} />
                      </button>
                    ))}
                  </div>
                  <div className="phase-explainer">
                    <div className={`phase-kind-mark kind-${(activePhase === null ? plan.phases[0] : plan.phases.find(phase => phase.id === activePhase))?.kind ?? "troop"}`}><ArrowDownRight size={16} /></div>
                    <div className="phase-copy">
                      <span>{activePhase === null ? "MULAI DARI TAHAP PERTAMA" : `TAHAP ${String(activePhase).padStart(2, "0")} · ${kindLabel(plan.phases.find(phase => phase.id === activePhase)?.kind ?? "troop")}`}</span>
                      <strong>{activePhase === null ? plan.phases[0]?.title : plan.phases.find(phase => phase.id === activePhase)?.title}</strong>
                      <p>{activePhase === null ? plan.phases[0]?.instruction : plan.phases.find(phase => phase.id === activePhase)?.instruction}</p>
                    </div>
                    <button className="phase-next" onClick={() => {
                      const currentIndex = activePhase === null ? 0 : plan.phases.findIndex(phase => phase.id === activePhase);
                      const next = plan.phases[currentIndex + 1];
                      setActivePhase(next ? next.id : null);
                    }} aria-label="Langkah berikutnya"><ArrowRight size={18} /></button>
                  </div>
                </div>
              ) : (
                <div className="map-hint"><Crosshair size={14} /><span>{imageDataUrl ? "Peta siap dianalisis — tandai pasukan dan jalankan analisis." : "Overlay penempatan akan muncul di atas gambar base setelah analisis."}</span><span className="map-hint-end">COORDINATE GRID <i>OFF</i></span></div>
              )}

              <div className="disclosure"><CircleHelp size={14} /><span>AI memberi perkiraan dari screenshot. Selalu cocokkan detail base dan jumlah pasukan sebelum serangan war.</span></div>
            </section>

            <aside className="profile-column" id="troop-profile">
              <div className="section-topline profile-topline">
                <div className="section-label"><span className="step-index">02</span><div><span>PLAYER LOADOUT</span><strong>Profil pasukanmu</strong></div></div>
                <span className="profile-save"><LockKeyhole size={12} /> LOKAL</span>
              </div>

              <div className="profile-card">
                <div className="profile-card-top"><div><span className="card-overline">AKUN PENYERANG</span><strong>Data army</strong></div><div className="profile-orbit"><Swords size={17} /></div></div>
                <input ref={profileFileInputRef} className="visually-hidden" type="file" accept="image/png,image/jpeg,image/webp" onChange={onProfileFileChange} />
                <div
                  className={`profile-import ${profileDragging ? "dragging" : ""}`}
                  onDragOver={event => { event.preventDefault(); setProfileDragging(true); }}
                  onDragLeave={event => { if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setProfileDragging(false); }}
                  onDrop={event => { event.preventDefault(); setProfileDragging(false); void pickProfileScreenshot(event.dataTransfer.files?.[0]); }}
                >
                  {profileScreenshot ? (
                    <div className="profile-import-preview">
                      <img src={profileScreenshot} alt="Pratinjau screenshot profil akun Clash of Clans" />
                      <div className="profile-import-copy">
                        <span className="card-overline">{profilePreparing ? "MEMPROSES SCREENSHOT" : profileParseResult?.troops.length ? "HASIL PROFIL TERBACA" : profileParseResult ? "HASIL BELUM LENGKAP" : "SCREENSHOT PROFIL"}</span>
                        <strong>{profileScreenshotName || "Screenshot profil akun"}</strong>
                        {profileParseResult && <span className="profile-import-result">{profileParseResult.troops.length} troop · {profileParseResult.heroes.length} hero · {profileParseResult.spells.length} spell · {confidenceLabel(profileParseResult.confidence)}</span>}
                        {profileParseResult && <span className="profile-import-result">Town Hall dari screenshot: {profileParseResult.townHall ? `TH ${profileParseResult.townHall} terdeteksi` : profile.townHall ? `tidak terbaca; TH ${profile.townHall} sebelumnya dipertahankan—verifikasi manual` : "tidak terbaca; pilih manual"}.</span>}
                        {profilePreparing && <span className="profile-import-result">Gambar sedang disiapkan atau dianalisis; tunggu sebelum memilih screenshot lain…</span>}
                        {profileParseResult?.notes.length ? <span className="profile-import-notes">{profileParseResult.notes.slice(0, 3).join(" · ")}</span> : null}
                      </div>
                      <button type="button" className="profile-import-change" onClick={() => profileFileInputRef.current?.click()} disabled={profilePreparing || profileParser.isPending} aria-label="Ganti screenshot profil"><RotateCcw size={14} /></button>
                    </div>
                  ) : (
                    <button type="button" className="profile-import-trigger" onClick={() => profileFileInputRef.current?.click()} disabled={profilePreparing || profileParser.isPending}>
                      <span className="profile-import-icon"><FileImage size={17} /><Upload size={11} /></span>
                      <span className="profile-import-copy"><strong>{profilePreparing ? "Menyiapkan screenshot…" : profileDragging ? "Lepaskan screenshot profil" : "Seret screenshot profil akun ke sini"}</strong><small>AI membaca troop, hero, spell, dan level yang terlihat</small></span>
                      <span className="profile-import-action">UNGGAH</span>
                    </button>
                  )}
                </div>
                <div className="profile-import-disclosure">Website tidak menyimpan screenshot; gambar dikirim ke provider AI untuk dibaca. Periksa hasil dan koreksi level atau unit yang belum pasti.</div>
                <label className="field-label" htmlFor="townhall">TOWN HALL LEVEL <span className="required-dot">*</span></label>
                <div className="select-field">
                  <select id="townhall" value={profile.townHall ?? ""} onChange={event => setProfile(current => ({ ...current, townHall: event.target.value ? Number(event.target.value) : null }))}>
                    <option value="">Pilih level Town Hall</option>
                    {Array.from({ length: 20 }, (_, index) => index + 1).map(level => <option key={level} value={level}>Town Hall {level}</option>)}
                  </select>
                  <ChevronDown size={15} />
                </div>
                <label className="field-label capacity-label" htmlFor="capacity">KAPASITAS ARMY CAMP <span className="optional-tag">OPSIONAL</span></label>
                <div className="capacity-field"><input id="capacity" type="number" min={1} max={500} inputMode="numeric" placeholder="Mis. 320" value={profile.armyCapacity ?? ""} onChange={event => setProfile(current => ({ ...current, armyCapacity: event.target.value ? Number(event.target.value) : undefined }))} /><span>ruang</span></div>

                <div className="loadout-heading"><span>UNIT YANG TERSEDIA</span><span className="loadout-line" /></div>
                <div className="category-tabs" role="tablist" aria-label="Kategori unit">
                  {(["troops", "heroes", "spells"] as UnitCategory[]).map(category => (
                    <button key={category} role="tab" aria-selected={activeCategory === category} className={activeCategory === category ? "category-active" : ""} onClick={() => { setActiveCategory(category); setUnitSearch(""); }}>
                      {category === "troops" ? <Flame size={14} /> : category === "heroes" ? <Crown size={14} /> : <Sparkles size={14} />}
                      {CATEGORY_LABELS[category]}<span>{profile[category].length}</span>
                    </button>
                  ))}
                </div>
                <div className="unit-search"><Crosshair size={14} /><input aria-label={`Cari ${CATEGORY_LABELS[activeCategory]}`} value={unitSearch} onChange={event => setUnitSearch(event.target.value)} placeholder={`Cari ${CATEGORY_LABELS[activeCategory].toLowerCase()}...`} />{unitSearch && <button onClick={() => setUnitSearch("")} aria-label="Bersihkan pencarian"><X size={14} /></button>}</div>
                <div className="unit-list">
                  {filteredUnits.map((name, index) => {
                    const selected = profile[activeCategory].find(unit => unit.name === name);
                    return (
                      <div key={name} className={`unit-row ${selected ? "unit-row-selected" : ""}`}>
                        <button className={`unit-check ${selected ? "checked" : ""}`} onClick={() => toggleUnit(activeCategory, name, !selected)} aria-pressed={Boolean(selected)} aria-label={`${selected ? "Hapus" : "Pilih"} ${name}`}>
                          {selected ? <Check size={12} /> : <span>{String(index + 1).padStart(2, "0")}</span>}
                        </button>
                        <button className="unit-name" onClick={() => toggleUnit(activeCategory, name, !selected)}>{name}</button>
                        {selected ? (
                          <div className="unit-controls">
                            {activeCategory === "spells" && <><label htmlFor={`qty-${name}`} className="unit-control-label">×</label><input id={`qty-${name}`} type="number" min={1} max={20} value={selected.quantity ?? 1} onChange={event => updateUnit(activeCategory, name, "quantity", Math.max(1, Number(event.target.value) || 1))} aria-label={`Jumlah ${name}`} /></>}
                            <label htmlFor={`lvl-${name}`} className="unit-control-label">LV</label><input id={`lvl-${name}`} type="number" min={1} max={150} placeholder="?" value={selected.level ?? ""} onChange={event => updateUnit(activeCategory, name, "level", event.target.value === "" ? null : Math.max(1, Number(event.target.value) || 1))} aria-label={`Level ${name}; kosongkan bila tidak diketahui`} title="Kosongkan bila level tidak diketahui" />
                          </div>
                        ) : <span className="unit-locked">BELUM DIPILIH</span>}
                      </div>
                    );
                  })}
                  {filteredUnits.length === 0 && <div className="empty-unit-search">Tidak ada hasil. Gunakan tombol tambah unit di bawah.</div>}
                </div>
                <button className="add-custom-unit" onClick={addCustomUnit}><Plus size={13} /> Tambah unit lain <span>(nama khusus)</span></button>
                <div className="category-count"><span>{selectedCount} {CATEGORY_COUNTS[activeCategory]}</span><span>{profile.troops.length + profile.heroes.length + profile.spells.length} UNIT TOTAL</span></div>
              </div>

              <div className={`profile-ready ${hasProfile ? "ready" : ""}`}>
                <span className="ready-indicator">{hasProfile ? <Check size={13} /> : <CircleHelp size={13} />}</span>
                <span>{hasProfile ? `TH ${profile.townHall} · ${profile.troops.length} troop · ${profile.heroes.length} hero · ${profile.spells.length} spell` : "Unggah screenshot profil atau pilih Town Hall dan troop yang tersedia."}</span>
              </div>

              <button className="analyze-button" disabled={analysis.isPending || profileParser.isPending || profilePreparing} onClick={() => void handleAnalyze()}>
                {profilePreparing ? <><LoaderCircle size={17} className="spin" /> MENYIAPKAN PROFIL...</> : profileParser.isPending ? <><LoaderCircle size={17} className="spin" /> MEMBACA PROFIL...</> : analysis.isPending ? <><LoaderCircle size={17} className="spin" /> MEMBACA BASE...</> : <><WandSparkles size={17} /> ANALISIS & RENCANAKAN <ArrowRight size={16} /></>}
              </button>
              <div className="analyze-caption"><span className="caption-dot" />Foto dan profil dikirim ke provider AI yang dikonfigurasi; biaya mengikuti provider tersebut.</div>
            </aside>
          </div>

          <section className="results-section" id="analysis-result">
            {analysis.isPending ? (
              <div className="analysis-loading">
                <div className="loading-spinner"><LoaderCircle size={23} /></div>
                <div><span className="card-overline">VISION ANALYZER · SEDANG BEKERJA</span><strong>Membaca tata letak base</strong><p>Menandai pertahanan, titik masuk, dan susunan army yang tersedia.</p></div>
                <div className="loading-scanline" />
              </div>
            ) : plan ? (
              <AttackResults plan={plan} profile={profile} onClear={() => setPlan(null)} />
            ) : (
              <div className="results-placeholder">
                <div className="placeholder-icon"><Target size={21} /></div>
                <div><span className="card-overline">03 / SERANGAN TERARAH</span><strong>Rencana serangmu muncul di sini</strong><p>Unggah base, pilih loadout, lalu jalankan analisis untuk melihat komposisi dan deployment overlay.</p></div>
                <span className="placeholder-route">{imageDataUrl ? "BASE READY" : "AWAITING INPUT"} <ArrowRight size={14} /></span>
              </div>
            )}
          </section>

          <footer className="page-footer"><span>BASEWAR TACTICS <i>·</i> BATTLE INTELLIGENCE</span><span>AI-ASSISTED PLAN <i>·</i> REVIEW BEFORE DEPLOY</span></footer>
        </div>
      </main>
    </div>
  );
}

function AttackResults({ plan, profile, onClear }: { plan: AttackPlan; profile: PlayerProfile; onClear: () => void }) {
  return (
    <div className="results-card">
      <div className="results-header">
        <div className="results-title-wrap"><span className="results-icon"><Swords size={17} /></span><div><span className="card-overline">03 / RENCANA SERANGAN</span><h2>{plan.strategyTitle}</h2></div></div>
        <button className="clear-plan" onClick={onClear}><X size={14} /> Tutup rencana</button>
      </div>
      <div className="strategy-strip">
        <div className="strategy-metric"><span>JENIS</span><strong>{plan.strategyType}</strong></div>
        <div className="strategy-metric"><span>ARAH MASUK</span><strong>{plan.entryDirection}</strong></div>
        <div className="strategy-metric"><span>TARGET UTAMA</span><strong>{plan.coreTarget}</strong></div>
        <div className="strategy-metric"><span>TINGKAT KESULITAN</span><strong>{plan.difficulty}</strong></div>
      </div>
      <div className="results-intro"><div><span className="card-overline">INTEL BASE · TH TERDETEKSI {plan.townHallDetected || "TIDAK PASTI"}</span><p>{plan.baseSummary}</p></div><div className={`confidence-chip confidence-${plan.confidence}`}><span />{confidenceLabel(plan.confidence)}</div></div>
      {profile.armyCapacity == null && <div className="capacity-warning"><AlertTriangle size={15} /><span>Kapasitas Army Camp belum diisi. Jumlah komposisi perlu dicocokkan dengan kapasitas akun sebelum menyerang.</span></div>}

      <div className="result-columns">
        <div className="result-subpanel">
          <div className="result-subhead"><span>ARMY COMPOSITION</span><span>{plan.composition.length} UNIT JENIS</span></div>
          <div className="composition-list">
            {plan.composition.map((item, index) => (
              <div className="composition-row" key={`${item.category}-${item.name}-${index}`}>
                <span className={`composition-symbol symbol-${item.category}`}>{item.category === "hero" ? <Crown size={13} /> : item.category === "spell" ? <Sparkles size={13} /> : <Flame size={13} />}</span>
                <div className="composition-name"><strong>{item.name}</strong><span>{item.role}</span></div>
                <span className="composition-qty">×{item.quantity}</span>
              </div>
            ))}
          </div>
          <div className="composition-foot">Sesuai profil · TH {profile.townHall}</div>
        </div>
        <div className="result-subpanel targets-panel">
          <div className="result-subhead"><span>ANALISIS TARGET</span><span>{plan.keyTargets.length} DITEMUKAN</span></div>
          {plan.keyTargets.map((target, index) => (
            <div className="target-row" key={`${target.name}-${index}`}><span className={`target-severity severity-${target.severity}`}>{String(index + 1).padStart(2, "0")}</span><div><strong>{target.name}</strong><span>{target.note}</span></div></div>
          ))}
          {plan.weakPoints.length > 0 && <div className="weak-point-list"><span className="weak-title">TITIK LEMAH TERLIHAT</span>{plan.weakPoints.slice(0, 3).map((point, index) => <div key={`${point.title}-${index}`}><MapPin size={12} /><span><b>{point.title}</b> — {point.detail}</span></div>)}</div>}
        </div>
      </div>

      <div className="risk-alternatives">
        <div className="risk-box"><span className="risk-heading"><AlertTriangle size={13} /> RISIKO</span>{plan.risks.map((risk, index) => <p key={index}>{risk}</p>)}</div>
        <div className="alt-box"><span className="risk-heading"><RotateCcw size={13} /> OPSI CADANGAN</span>{plan.alternatives.map((alternative, index) => <p key={index}>{alternative}</p>)}</div>
      </div>
      <div className="results-note"><LockKeyhole size={13} /><span>Rencana dibuat dari gambar dan profil yang Anda kirim. Periksa lagi detail base; AI bisa keliru membaca bangunan kecil atau tertutup efek visual.</span></div>
    </div>
  );
}
