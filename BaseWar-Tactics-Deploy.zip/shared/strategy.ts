export type UnitCategory = "troops" | "heroes" | "spells";

export type ProfileUnit = {
  name: string;
  level: number | null;
  quantity?: number;
};

export type PlayerProfile = {
  townHall: number | null;
  armyCapacity?: number;
  troops: ProfileUnit[];
  heroes: ProfileUnit[];
  spells: ProfileUnit[];
};

export type ProfileParseResult = Pick<PlayerProfile, "townHall" | "troops" | "heroes" | "spells"> & {
  confidence: "rendah" | "sedang" | "tinggi";
  notes: string[];
};

export type PlanConfidence = "rendah" | "sedang" | "tinggi";
export type PlanDifficulty = "mudah" | "sedang" | "sulit";
export type DeploymentKind = "troop" | "hero" | "spell" | "movement";

export type BaseMarker = {
  name: string;
  note: string;
  severity: "utama" | "sedang" | "rendah";
  x: number;
  y: number;
};

export type WeakPoint = {
  title: string;
  detail: string;
  x: number;
  y: number;
};

export type ArmyEntry = {
  name: string;
  category: "troop" | "hero" | "spell";
  quantity: number;
  role: string;
  reason: string;
};

export type AttackPhase = {
  id: number;
  title: string;
  kind: DeploymentKind;
  unit: string;
  quantity: number;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  instruction: string;
  purpose: string;
};

export type AttackPlan = {
  baseSummary: string;
  townHallDetected: string;
  confidence: PlanConfidence;
  keyTargets: BaseMarker[];
  weakPoints: WeakPoint[];
  strategyTitle: string;
  strategyType: string;
  entryDirection: string;
  coreTarget: string;
  difficulty: PlanDifficulty;
  composition: ArmyEntry[];
  phases: AttackPhase[];
  risks: string[];
  alternatives: string[];
};
