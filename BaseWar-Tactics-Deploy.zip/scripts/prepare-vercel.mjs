import { cp, mkdir, rm } from "node:fs/promises";
import path from "node:path";

const source = path.resolve("dist/public");
const destination = path.resolve("public");

await rm(destination, { recursive: true, force: true });
await mkdir(destination, { recursive: true });
await cp(source, destination, { recursive: true });

console.log("Vite assets copied to public/ for Vercel static delivery.");
